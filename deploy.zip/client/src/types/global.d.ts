// Add Google Maps to window object
interface Window {
  google: any;
}