#!/bin/bash

# Build the web app
npm run build

# Sync with Capacitor
npx cap sync